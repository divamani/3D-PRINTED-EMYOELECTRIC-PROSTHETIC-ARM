
//int EMGPin= A0;
//int EMGVal= 0;
//void setup() {+
//Serial.begin(9600);
//}
//void loop() {
//EMGVal= analogRead(EMGPin);
//Serial.println(EMGVal);
//}


#include<Servo.h>
int EMGPin= A0;
long EMGVal= 0;
Servo servo1;
Servo servo2;
Servo servo3;
Servo servo4;
Servo servo5;
constint servoPin1 = 2;
constint servoPin2 = 3;

constint servoPin2 = 3;
constint servoPin3 = 4;
constint servoPin4 = 5;
constint servoPin5 = 6;
int pos=0;
void setup()
{
Serial.begin(9600);
servo1.attach(servoPin1);
servo2.attach(servoPin2);
servo3.attach(servoPin3);
servo4.attach(servoPin4);
servo5.attach(servoPin5);
servo1.write(120);
//piservo2.write(120)
;servo3.write(120);
servo4.write(120);
servo5.write(120);
delay(2000);
//pinkyservo1.write(20);
Serial.println("servo1");
delay(1000);
//middleservo2.write(20);
Serial.println("servo2");
delay(1000);
{
if(pos=1){
servo1.write(20);
servo2.write(20);
servo3.write(20);
servo4.write(20);
servo5.write(20);
delay(2000);
pos=0;

}}
Elseif(EMGVal<=430){
if(pos==0){
servo1.write(120);
servo2.write(120);
servo3.write(120);s
ervo4.write(120);
servo5.write(120);
delay(2000);
pos=1;
}
}
}